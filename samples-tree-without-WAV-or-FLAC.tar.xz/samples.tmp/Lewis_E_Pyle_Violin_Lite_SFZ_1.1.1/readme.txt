This sample library was prepared by David Hilowitz for Decent|Samples.

Enjoy!

Release Notes
=============

1.0 - Initial release