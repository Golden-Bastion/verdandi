#!/usr/bin/env python3
"""Render a short offline audition WAV from a simple SFZ instrument map.

Supports the common SFZ subset used by simple sampled instruments:
<global>, <group>, <region>, sample=, key/lokey/hikey, pitch_keycenter,
and ampeg_release. Source samples must be uncompressed PCM WAV files.
This is a convenience audition renderer, not a complete SFZ engine.
"""
from __future__ import annotations
import argparse
import math
import re
import struct
import sys
import wave
from array import array
from pathlib import Path

OPCODE_RE = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)=([^\s]+)")
SECTION_RE = re.compile(r"<(global|group|region)>|([^<]+)")

# A short, gentle phrase in a comfortable register. MIDI 60 is C4.
DEFAULT_NOTES = [60, 64, 67, 72, 71, 67, 64, 60, 62, 65, 69, 74, 72, 69, 65, 62]
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def parse_sfz(path: Path) -> tuple[dict[str, str], list[dict[str, str]]]:
    global_ops: dict[str, str] = {}
    group_ops: dict[str, str] = {}
    regions: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    scope = "global"

    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        # SFZ's // comment convention, sufficient for the supplied patch.
        line = raw.split("//", 1)[0].strip()
        if not line:
            continue
        # Process section tags and any opcodes appearing after them.
        parts = re.split(r"(<(?:global|group|region)>)", line)
        for part in parts:
            part = part.strip()
            if not part:
                continue
            if part == "<global>":
                scope = "global"
                continue
            if part == "<group>":
                scope = "group"
                group_ops = {}
                continue
            if part == "<region>":
                if current is not None:
                    regions.append(current)
                current = {**global_ops, **group_ops}
                scope = "region"
                continue
            ops = dict(OPCODE_RE.findall(part))
            if not ops:
                continue
            if scope == "global":
                global_ops.update(ops)
                if current is not None:
                    current.update(ops)
            elif scope == "group":
                group_ops.update(ops)
            elif current is not None:
                current.update(ops)
    if current is not None:
        regions.append(current)
    if not regions:
        raise ValueError(f"No <region> entries found in {path}")
    return global_ops, regions


def region_bounds(region: dict[str, str]) -> tuple[int, int, int]:
    if "key" in region:
        key = int(region["key"])
        low = int(region.get("lokey", key))
        high = int(region.get("hikey", key))
    else:
        low = int(region.get("lokey", "0"))
        high = int(region.get("hikey", "127"))
        key = int(region.get("pitch_keycenter", str((low + high) // 2)))
    center = int(region.get("pitch_keycenter", str(key)))
    return low, high, center


def choose_region(regions: list[dict[str, str]], note: int) -> dict[str, str]:
    matches = []
    for region in regions:
        if "sample" not in region:
            continue
        low, high, center = region_bounds(region)
        if low <= note <= high:
            matches.append((abs(note - center), region))
    if matches:
        return min(matches, key=lambda item: item[0])[1]

    available = []
    for region in regions:
        if "sample" not in region:
            continue
        low, high, center = region_bounds(region)
        distance = low - note if note < low else note - high if note > high else 0
        available.append((distance, abs(note - center), region))
    if not available:
        raise ValueError("No regions with sample= entries were found")
    return min(available, key=lambda item: (item[0], item[1]))[2]


def read_pcm_mono(path: Path) -> tuple[int, array]:
    with wave.open(str(path), "rb") as wav:
        channels = wav.getnchannels()
        width = wav.getsampwidth()
        rate = wav.getframerate()
        frames = wav.getnframes()
        comptype = wav.getcomptype()
        raw = wav.readframes(frames)
    if comptype != "NONE":
        raise ValueError(f"{path}: expected uncompressed PCM WAV, found {comptype}")
    if channels < 1 or channels > 8:
        raise ValueError(f"{path}: unsupported channel count {channels}")

    mono = array("f")
    if width == 1:
        values = raw  # unsigned 8-bit PCM
        count = len(values) // channels
        for i in range(count):
            mono.append(sum((values[i * channels + c] - 128) / 128.0 for c in range(channels)) / channels)
    elif width == 2:
        ints = array("h")
        ints.frombytes(raw)
        if sys.byteorder != "little":
            ints.byteswap()
        count = len(ints) // channels
        for i in range(count):
            mono.append(sum(ints[i * channels + c] / 32768.0 for c in range(channels)) / channels)
    elif width == 3:
        count = len(raw) // (3 * channels)
        for i in range(count):
            value_sum = 0.0
            for c in range(channels):
                j = (i * channels + c) * 3
                n = raw[j] | (raw[j + 1] << 8) | (raw[j + 2] << 16)
                if n & 0x800000:
                    n -= 1 << 24
                value_sum += n / 8388608.0
            mono.append(value_sum / channels)
    elif width == 4:
        ints = array("i")
        ints.frombytes(raw)
        if sys.byteorder != "little":
            ints.byteswap()
        count = len(ints) // channels
        for i in range(count):
            mono.append(sum(ints[i * channels + c] / 2147483648.0 for c in range(channels)) / channels)
    else:
        raise ValueError(f"{path}: unsupported PCM sample width {width} bytes")
    return rate, mono


def midi_name(note: int) -> str:
    return f"{NOTE_NAMES[note % 12]}{note // 12 - 1}"


def render(sfz_path: Path, output_path: Path, notes: list[int], bpm: float,
           gate_seconds: float, release_seconds: float, velocity: float) -> None:
    global_ops, regions = parse_sfz(sfz_path)
    out_rate = 44100
    beat_seconds = 60.0 / bpm
    spacing = beat_seconds * 0.8
    total_seconds = (len(notes) - 1) * spacing + gate_seconds + release_seconds + 0.25
    mix = array("f", [0.0]) * math.ceil(total_seconds * out_rate)
    cache: dict[Path, tuple[int, array]] = {}
    report: list[tuple[int, str, str, int]] = []

    if not (0.05 <= velocity <= 1.0):
        raise ValueError("velocity must be between 0.05 and 1.0")
    release_opcode = float(global_ops.get("ampeg_release", "1.0"))
    # Don't let an unusually long SFZ release turn a brief audition into a huge file.
    release = min(max(release_seconds, 0.1), max(0.1, release_opcode))

    for index, note in enumerate(notes):
        if not 0 <= note <= 127:
            raise ValueError(f"MIDI note out of range: {note}")
        region = choose_region(regions, note)
        sample_rel = region["sample"].replace("\\", "/")
        sample_path = (sfz_path.parent / sample_rel).resolve()
        if not sample_path.is_file():
            raise FileNotFoundError(f"Sample not found for {midi_name(note)}: {sample_path}")
        if sample_path not in cache:
            cache[sample_path] = read_pcm_mono(sample_path)
        source_rate, samples = cache[sample_path]
        _, _, center = region_bounds(region)
        ratio = 2.0 ** ((note - center) / 12.0) * (source_rate / out_rate)
        start = round(index * spacing * out_rate)
        max_frames = min(
            len(samples) and math.ceil(len(samples) / ratio) or 0,
            math.ceil((gate_seconds + release) * out_rate),
            len(mix) - start,
        )
        if max_frames <= 0:
            continue
        for j in range(max_frames):
            source_pos = j * ratio
            left = int(source_pos)
            if left >= len(samples):
                break
            right = min(left + 1, len(samples) - 1)
            frac = source_pos - left
            sample = samples[left] * (1.0 - frac) + samples[right] * frac
            t = j / out_rate
            if t > gate_seconds:
                # Smooth exponential release, retaining a natural sample decay.
                tail = t - gate_seconds
                sample *= math.exp(-5.0 * tail / release)
            mix[start + j] += sample * velocity
        report.append((note, sample_path.name, midi_name(note), center))

    peak = max((abs(v) for v in mix), default=0.0)
    gain = min(1.0, 0.92 / peak) if peak > 0 else 1.0
    pcm = bytearray()
    for value in mix:
        n = int(max(-1.0, min(1.0, value * gain)) * 32767.0)
        pcm.extend(struct.pack("<hh", n, n))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(output_path), "wb") as out:
        out.setnchannels(2)
        out.setsampwidth(2)
        out.setframerate(out_rate)
        out.writeframes(pcm)
    print(f"Wrote {output_path} ({len(mix) / out_rate:.1f} s, {out_rate} Hz stereo PCM16)")
    print("Notes rendered:")
    for note, sample_name, note_name, center in report:
        transposed = " (pitch-shifted)" if note != center else ""
        print(f"  {note_name:4s} -> {sample_name} [root {midi_name(center)}]{transposed}")
    if not report:
        raise ValueError("No notes were rendered")


def parse_notes(text: str) -> list[int]:
    # Deliberately accept MIDI numbers only for a simple, unambiguous CLI.
    try:
        result = [int(part.strip()) for part in text.split(",") if part.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("notes must be comma-separated MIDI numbers, e.g. 60,64,67,72") from exc
    if not result:
        raise argparse.ArgumentTypeError("at least one MIDI note is required")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("sfz", type=Path, help="path to the .sfz file")
    parser.add_argument("output", type=Path, help="output .wav path")
    parser.add_argument("--notes", type=parse_notes, default=DEFAULT_NOTES,
                        help="comma-separated MIDI note numbers (default: a short melody in C)")
    parser.add_argument("--bpm", type=float, default=100.0, help="audition tempo (default: 100)")
    parser.add_argument("--gate", type=float, default=0.32, help="seconds before release starts (default: 0.32)")
    parser.add_argument("--release", type=float, default=1.0, help="release time in seconds, capped by SFZ ampeg_release (default: 1.0)")
    parser.add_argument("--velocity", type=float, default=0.8, help="note velocity from 0.05 to 1.0 (default: 0.8)")
    args = parser.parse_args()
    try:
        if not args.sfz.is_file():
            raise FileNotFoundError(args.sfz)
        if args.bpm <= 0:
            raise ValueError("BPM must be positive")
        render(args.sfz.resolve(), args.output.resolve(), args.notes, args.bpm,
               args.gate, args.release, args.velocity)
    except (OSError, ValueError, wave.Error) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
